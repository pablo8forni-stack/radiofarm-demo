/**
 * RadioFarm — Sistema de Gestión de Radiofármacos
 *
 * Copyright © 2025 Pablo Forni. Todos los derechos reservados.
 *
 * Este software y su documentación asociada son propiedad exclusiva
 * de Pablo Forni (en adelante "el Autor"). Queda estrictamente prohibido,
 * sin autorización expresa y por escrito del Autor:
 *
 *   - Copiar, reproducir o duplicar este software total o parcialmente
 *   - Modificar, adaptar o crear obras derivadas
 *   - Distribuir, sublicenciar o transferir a terceros
 *   - Usar con fines comerciales sin licencia vigente
 *
 * El uso de este software por parte de una institución no implica
 * transferencia de propiedad ni de derechos de autor.
 *
 * Para licencias comerciales, contacto o autorizaciones:
 * pablo@email.com — Mendoza, Argentina
 *
 * Obra registrada ante la Dirección Nacional del Derecho de Autor
 * (DNDA), República Argentina. Ley 11.723.
 */

import { useEffect, useState } from "react";
import { useAuth } from "./hooks/useAuth.js";
import { useCatalogo } from "./hooks/useCatalogo.js";
import { CatalogoProvider } from "./context/CatalogoContext.jsx";
import { PantallaLogin } from "./views/PantallaLogin.jsx";
import { VistaInventario } from "./views/inventario/VistaInventario.jsx";
import { VistaPedidos } from "./views/VistaPedidos.jsx";
import { VistaHistorial } from "./views/VistaHistorial.jsx";
import { VistaAdministracion } from "./views/administracion/VistaAdministracion.jsx";
import { VistaTerapiaI131 } from "./views/VistaTerapiaI131.jsx";
import { VistaConfiguracion } from "./views/configuracion/VistaConfiguracion.jsx";
import { Badge } from "./components/ui/Badge.jsx";
import { Btn } from "./components/ui/Btn.jsx";
import { Toast } from "./components/ui/Toast.jsx";
import { AcercaDe } from "./components/AcercaDe.jsx";
import { signOutUser, listenSolicitudes } from "./services/auth.js";
import { totStock, farmsDeSede, sedesActivas, idsSedesActivas, puntoReorden } from "./helpers/stock.js";
import { hayOperacionCriticaEnCurso } from "./helpers/erroresRed.js";
import { avisosSoportados, avisosActivados, activarAvisos, desactivarAvisos, sincronizarYAvisar, CLAVES_ALMACEN } from "./helpers/avisos.js";

export default function App() {
  const { usuario, cargando } = useAuth();

  if (cargando) return <PantallaCargando />;
  if (!usuario) return <PantallaLogin />;
  if (usuario.sinAcceso) return <PantallaSinAcceso usuario={usuario} />;

  return (
    <CatalogoProvider>
      <AppAutenticada usuario={usuario} />
    </CatalogoProvider>
  );
}

function AppAutenticada({ usuario }) {
  const catalogo = useCatalogo();
  const [vista, setVista] = useState("inventario");
  const [toast, setToast] = useState(null);
  const [mostrarAcercaDe, setMostrarAcercaDe] = useState(false);
  const esAdmin = usuario.rol === "admin";
  const [solicitudes, setSolicitudes] = useState([]);
  const countSolicitudes = solicitudes.length;
  const [navInventario, setNavInventario] = useState(null);
  const [navConfiguracion, setNavConfiguracion] = useState(null);
  const [navAdministracion, setNavAdministracion] = useState(null);
  const [avisosOn, setAvisosOn] = useState(() => avisosActivados());

  // Cambia a la vista Inventario y le pide mostrar una sede puntual --
  // usado por "Ir a Inventario de X" en el modal de stock pendiente al
  // archivar una sede (Configuración > Sedes activas).
  function irAInventario(sedeId) {
    setNavInventario({ sedeId, token: Date.now() });
    setVista("inventario");
  }

  // Mismo patrón que irAInventario -- usado por el chip "N solicitudes" y
  // por el click en la notificación del sistema, para ir directo a la
  // pestaña Usuarios en vez de dejar a Configuración en la que estuviera.
  function irAConfiguracion(tab) {
    setNavConfiguracion({ tab, token: Date.now() });
    setVista("configuracion");
  }

  // Mismo patrón -- usado por "Ir a Libro 2" cuando se bloquea la anulación
  // de un lote de MIBG/Lutecio-177 con una administración activa enganchada
  // (TabLoteDosisUnica.jsx). `extra` lleva la búsqueda a precargar (DNI del
  // paciente) para no obligar a buscarlo a mano. Se llama tanto desde
  // Gestión I-131 (MIBG) como desde Actas ARN > Libro 4 (Lutecio-177) --
  // en este último caso ya estamos en "administracion", el cambio de vista
  // es un no-op, pero el token igual dispara el efecto que cambia de sub-tab.
  function irAAdministracion(tab, extra = {}) {
    setNavAdministracion({ tab, ...extra, token: Date.now() });
    setVista("administracion");
  }

  async function toggleAvisos() {
    if (avisosOn) {
      desactivarAvisos();
      setAvisosOn(false);
      setToast({ m: "Avisos con sonido desactivados", t: "info" });
      return;
    }
    const ok = await activarAvisos();
    setAvisosOn(ok);
    setToast(ok
      ? { m: "Avisos con sonido activados — sonará ante nuevas solicitudes o stock bajo mientras la app esté abierta." }
      : { m: "No se pudo activar: revisá los permisos de notificaciones del navegador para este sitio.", t: "error" });
  }

  // Sólo admin puede leer la colección completa de solicitudes (reglas de
  // Firestore) -- un técnico consultándola entera daría permission-denied.
  useEffect(() => {
    if (!esAdmin) return;
    return listenSolicitudes(setSolicitudes);
  }, [esAdmin]);

  // Aviso local (sonido + Notification) ante solicitudes de acceso
  // genuinamente nuevas -- sincronizarYAvisar ya se encarga de no repetir
  // avisos de solicitudes ya vistas al recargar la página.
  useEffect(() => {
    if (!esAdmin) return;
    sincronizarYAvisar(CLAVES_ALMACEN.SOLICITUDES, solicitudes.map((s) => s.email), (email) => {
      const s = solicitudes.find((x) => x.email === email);
      return {
        titulo: "Nueva solicitud de acceso",
        cuerpo: s?.nombre ? `${s.nombre} (${email})` : email,
        onClick: () => irAConfiguracion("usuarios"),
      };
    });
  }, [esAdmin, solicitudes]);

  // Egreso/transferencia/anulación no fallan de forma confiable y rápida sin
  // conexión (ver nota en helpers/erroresRed.js) -- si la señal vuelve
  // mientras alguna de esas operaciones seguía en curso, no hay forma de
  // saber desde acá si llegó a aplicarse antes del corte. El id de operación
  // ya evita que un reintento la duplique; esto es sólo para avisar que
  // convenga revisar el Historial ante la duda.
  useEffect(() => {
    function avisarReconexion() {
      if (hayOperacionCriticaEnCurso()) {
        setToast({
          m: "Se restableció la conexión — revisá el Historial para confirmar que tu última operación se haya registrado.",
          t: "info", d: 8000,
        });
      }
    }
    window.addEventListener("online", avisarReconexion);
    return () => window.removeEventListener("online", avisarReconexion);
  }, []);

  // Aviso local ante ítems que CRUZAN por debajo del mínimo (no mientras
  // siguen ahí) -- mismo criterio de flanco que solicitudes, ver avisos.js.
  // Sólo admin: gestionar compras no es responsabilidad de técnico, mismo
  // criterio que el chip/badge de "para pedir".
  useEffect(() => {
    if (catalogo.cargando || !esAdmin) return;
    const clavesBajas = [];
    sedesActivas(catalogo).forEach((sede) =>
      farmsDeSede(catalogo, sede.id).forEach((f) => {
        if (totStock(catalogo.stock[sede.id]?.[f.id] || []) <= puntoReorden(catalogo, sede.id, f.id)) {
          clavesBajas.push(`${sede.id}_${f.id}`);
        }
      })
    );
    sincronizarYAvisar(CLAVES_ALMACEN.STOCK_BAJO, clavesBajas, (clave) => {
      const [sedeId, farmId] = clave.split("_");
      const farm = catalogo.farms.find((f) => f.id === farmId);
      return { titulo: "Stock por debajo del mínimo", cuerpo: `${farm?.nombre || farmId} — ${catalogo.sedes[sedeId]?.nombre || sedeId}` };
    });
  }, [catalogo, esAdmin]);

  if (catalogo.cargando) return <PantallaCargando />;

  if (!esAdmin && !idsSedesActivas(catalogo).includes(usuario.sede)) {
    return <PantallaSedeNoHabilitada usuario={usuario} nombreSede={catalogo.sedes[usuario.sede]?.nombre} />;
  }

  let countPedirTotal = 0;
  sedesActivas(catalogo).forEach((sede) =>
    farmsDeSede(catalogo, sede.id).forEach((f) => {
      if (totStock(catalogo.stock[sede.id]?.[f.id] || []) <= puntoReorden(catalogo, sede.id, f.id)) countPedirTotal++;
    })
  );

  const navItems = [
    { id: "inventario", label: "Inventario", path: "M4 6h16M4 10h16M4 14h16M4 18h16" },
    ...(esAdmin ? [{ id: "pedidos", label: "Pedidos", path: "M9 5H7a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2V7a2 2 0 00-2-2h-2M9 5a2 2 0 002 2h2a2 2 0 002-2M9 5a2 2 0 012-2h2a2 2 0 012 2" }] : []),
    { id: "historial", label: "Historial", path: "M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" },
    { id: "administracion", label: "Actas ARN", labelCorta: "Actas", path: "M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" },
    { id: "terapia-i131", label: "Gestión I-131", labelCorta: "I-131", path: "M9.75 3.104v5.714a2.25 2.25 0 01-.659 1.591L5 14.5m4.75-11.396c.251.023.501.05.75.082m4.75-.082v5.714c0 .597.237 1.17.659 1.591L19.8 15.3m-5.55-12.196a24.301 24.301 0 00-4.5 0M19.8 15.3l-1.57.393A9.065 9.065 0 0112 15a9.065 9.065 0 00-6.23-.693L5 14.5m14.8.8l1.402 1.402c1.232 1.232.65 3.318-1.067 3.611A48.309 48.309 0 0112 21c-2.773 0-5.491-.235-8.135-.687-1.718-.293-2.3-2.379-1.067-3.61L5 14.5" },
    ...(esAdmin ? [{ id: "configuracion", label: "Config.", path: "M10.325 4.317c.426-1.756 2.924-1.756 3.35 0a1.724 1.724 0 002.573 1.066c1.543-.94 3.31.826 2.37 2.37a1.724 1.724 0 001.065 2.572c1.756.426 1.756 2.924 0 3.35a1.724 1.724 0 00-1.066 2.573c.94 1.543-.826 3.31-2.37 2.37a1.724 1.724 0 00-2.572 1.065c-.426 1.756-2.924 1.756-3.35 0a1.724 1.724 0 00-2.573-1.066c-1.543.94-3.31-.826-2.37-2.37a1.724 1.724 0 00-1.065-2.572c-1.756-.426-1.756-2.924 0-3.35a1.724 1.724 0 001.066-2.573c-.94-1.543.826-3.31 2.37-2.37.996.608 2.296.07 2.572-1.065z M15 12a3 3 0 11-6 0 3 3 0 016 0z" }] : []),
  ];

  // countBadge por id, reusado tanto en el nav de arriba (desktop) como en la
  // barra inferior (mobile) -- un solo lugar para no repetir la lógica.
  const countBadge = (id) => (id === "pedidos" ? (esAdmin ? countPedirTotal : 0) : id === "configuracion" ? countSolicitudes : 0);

  return (
    <div className="min-h-screen bg-gray-50 font-sans">
      <header className="bg-white border-b border-gray-100 sticky top-0 z-30 shadow-sm">
        <div className="max-w-5xl mx-auto px-4 py-3 flex items-center justify-between gap-3">
          {/* Logo+nombre clickeable -> "Acerca de" (versión/copyright).
              Visible para cualquier usuario logueado (a diferencia de
              Configuración, que es admin-only) -- mismo patrón común de
              "click en el logo" que el resto de este tipo de apps. */}
          <button onClick={() => setMostrarAcercaDe(true)} className="flex items-center gap-3 hover:opacity-80 transition text-left">
            <div className="w-9 h-9 rounded-xl bg-blue-600 flex items-center justify-center shadow-sm flex-shrink-0">
              <svg className="w-5 h-5 text-white" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M19.428 15.428a2 2 0 00-1.022-.547l-2.387-.477a6 6 0 00-3.86.517l-.318.158a6 6 0 01-3.86.517L6.05 15.21a2 2 0 00-1.806.547M8 4h8l-1 1v5.172a2 2 0 00.586 1.414l5 5c1.26 1.26.367 3.414-1.415 3.414H4.828c-1.782 0-2.674-2.154-1.414-3.414l5-5A2 2 0 009 10.172V5L8 4z" />
              </svg>
            </div>
            <div>
              <div className="text-sm font-bold text-gray-800 leading-tight">RadioFarm</div>
              <div className="text-xs text-gray-400 leading-tight">{catalogo.sedes[usuario.sede]?.nombre || "FUESMEN"}</div>
            </div>
          </button>
          <div className="flex items-center gap-2">
            {esAdmin && countPedirTotal > 0 && (
              <button onClick={() => setVista("pedidos")} className="flex items-center gap-1.5 bg-red-50 border border-red-200 text-red-600 text-xs font-bold px-3 py-1.5 rounded-full hover:bg-red-100 transition">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />{countPedirTotal} para pedir
              </button>
            )}
            {esAdmin && countSolicitudes > 0 && (
              <button onClick={() => irAConfiguracion("usuarios")} className="flex items-center gap-1.5 bg-red-50 border border-red-200 text-red-600 text-xs font-bold px-3 py-1.5 rounded-full hover:bg-red-100 transition">
                <span className="w-2 h-2 bg-red-500 rounded-full animate-pulse" />{countSolicitudes} solicitud{countSolicitudes > 1 ? "es" : ""}
              </button>
            )}
            <div className="flex items-center gap-2 pl-2 border-l border-gray-100">
              {avisosSoportados() && (
                <button onClick={toggleAvisos}
                  title={avisosOn ? "Avisos con sonido activados — click para desactivar" : "Activar avisos con sonido (solicitudes, stock bajo)"}
                  className={`rounded-lg transition min-w-11 min-h-11 md:min-w-0 md:min-h-0 flex items-center justify-center ${avisosOn ? "text-blue-600 hover:bg-blue-50" : "text-gray-400 hover:text-gray-600 hover:bg-gray-100"}`}>
                  <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                  </svg>
                </button>
              )}
              <div className={`w-8 h-8 rounded-full flex items-center justify-center text-xs font-bold text-white ${esAdmin ? "bg-purple-500" : "bg-blue-500"}`}>{usuario.initial}</div>
              <div className="hidden sm:block">
                <div className="text-xs font-semibold text-gray-700 leading-tight">{usuario.nombre}</div>
                <div className="text-xs leading-tight"><Badge color={esAdmin ? "purple" : "blue"}>{esAdmin ? "Responsable" : "Técnico"}</Badge></div>
              </div>
              <button onClick={() => signOutUser()} className="text-gray-400 hover:text-red-500 rounded-lg hover:bg-red-50 transition min-w-11 min-h-11 md:min-w-0 md:min-h-0 flex items-center justify-center">
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M17 16l4-4m0 0l-4-4m4 4H7m6 4v1a3 3 0 01-3 3H6a3 3 0 01-3-3V7a3 3 0 013-3h4a3 3 0 013 3v1" />
                </svg>
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Nav superior: sólo md hacia arriba -- en mobile la reemplaza la barra inferior fija (más cerca del pulgar). */}
      <nav className="hidden md:block bg-white border-b border-gray-100">
        <div className="max-w-5xl mx-auto px-4 flex gap-0 overflow-x-auto">
          {navItems.map((item) => {
            const badge = countBadge(item.id);
            return (
              <button key={item.id} onClick={() => setVista(item.id)}
                className={`flex items-center gap-2 px-4 py-3 text-sm font-semibold border-b-2 transition whitespace-nowrap ${vista === item.id ? "border-blue-600 text-blue-600" : "border-transparent text-gray-500 hover:text-gray-700 hover:border-gray-200"}`}>
                <svg className="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                  <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.path} />
                </svg>
                <span>{item.label}</span>
                {badge > 0 && <span className="bg-red-500 text-white text-xs rounded-full w-4 h-4 flex items-center justify-center">{badge}</span>}
              </button>
            );
          })}
        </div>
      </nav>

      {/* Barra inferior: sólo debajo de md. Ícono + label apilados, target
          táctil = toda la columna (flex-1), badge superpuesto en el ícono. */}
      <nav className="md:hidden fixed bottom-0 inset-x-0 z-40 bg-white border-t border-gray-100 pb-[env(safe-area-inset-bottom)]">
        <div className="flex">
          {navItems.map((item) => {
            const badge = countBadge(item.id);
            return (
              <button key={item.id} onClick={() => setVista(item.id)}
                className={`flex-1 flex flex-col items-center gap-0.5 py-2 text-[10px] font-semibold transition ${vista === item.id ? "text-blue-600" : "text-gray-400"}`}>
                <span className="relative">
                  <svg className="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d={item.path} />
                  </svg>
                  {badge > 0 && (
                    <span className="absolute -top-1.5 -right-1.5 bg-red-500 text-white text-[9px] font-bold rounded-full min-w-[16px] h-4 px-1 flex items-center justify-center">
                      {badge}
                    </span>
                  )}
                </span>
                {item.labelCorta || item.label}
              </button>
            );
          })}
        </div>
      </nav>

      <main className="max-w-5xl mx-auto px-4 pt-6 pb-24 md:py-6">
        {vista === "inventario" && <VistaInventario catalogo={catalogo} usuario={usuario} esAdmin={esAdmin} onToast={(m, t, d) => setToast({ m, t, d })} navInventario={navInventario} />}
        {vista === "pedidos" && esAdmin && <VistaPedidos catalogo={catalogo} esAdmin={esAdmin} onToast={(m, t, d) => setToast({ m, t, d })} />}
        {vista === "historial" && <VistaHistorial catalogo={catalogo} usuario={usuario} esAdmin={esAdmin} onToast={(m, t, d) => setToast({ m, t, d })} />}
        {vista === "administracion" && <VistaAdministracion catalogo={catalogo} usuario={usuario} esAdmin={esAdmin} onToast={(m, t, d) => setToast({ m, t, d })} navAdministracion={navAdministracion} onIrAAdministracion={irAAdministracion} />}
        {vista === "terapia-i131" && <VistaTerapiaI131 catalogo={catalogo} usuario={usuario} esAdmin={esAdmin} onToast={(m, t, d) => setToast({ m, t, d })} onIrAAdministracion={irAAdministracion} />}
        {vista === "configuracion" && esAdmin && <VistaConfiguracion catalogo={catalogo} usuario={usuario} onToast={(m, t, d) => setToast({ m, t, d })} onIrAInventario={irAInventario} navConfiguracion={navConfiguracion} />}
      </main>

      {toast && <Toast msg={toast.m} type={toast.t || "success"} duracion={toast.d} onDone={() => setToast(null)} />}
      <AcercaDe open={mostrarAcercaDe} onClose={() => setMostrarAcercaDe(false)} />
    </div>
  );
}

function PantallaCargando() {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center">
      <div className="w-8 h-8 border-2 border-blue-600 border-t-transparent rounded-full animate-spin" />
    </div>
  );
}

function PantallaSinAcceso({ usuario }) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-10 max-w-sm text-center">
        <div className="w-14 h-14 mx-auto mb-5 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center">
          <svg className="w-7 h-7 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h2 className="text-base font-bold text-gray-800 mb-2">Solicitud enviada</h2>
        <p className="text-sm text-gray-500 mb-6">
          Tu solicitud de acceso ({usuario.email}) fue enviada. Un administrador te va a habilitar el acceso — probá iniciar sesión de nuevo en unos minutos.
        </p>
        <Btn variant="outline" onClick={() => signOutUser()}>Volver al inicio</Btn>
      </div>
    </div>
  );
}

function PantallaSedeNoHabilitada({ usuario, nombreSede }) {
  return (
    <div className="min-h-screen bg-gray-50 flex items-center justify-center p-6">
      <div className="bg-white rounded-3xl shadow-sm border border-gray-100 p-10 max-w-sm text-center">
        <div className="w-14 h-14 mx-auto mb-5 rounded-2xl bg-amber-50 border border-amber-100 flex items-center justify-center">
          <svg className="w-7 h-7 text-amber-500" fill="none" stroke="currentColor" viewBox="0 0 24 24">
            <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={1.8} d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
          </svg>
        </div>
        <h2 className="text-base font-bold text-gray-800 mb-2">Sede no habilitada</h2>
        <p className="text-sm text-gray-500 mb-6">
          {nombreSede} aún no está operando con RadioFarm. Consultá con el responsable de radiofarmacia.
        </p>
        <Btn variant="outline" onClick={() => signOutUser()}>Volver al inicio</Btn>
      </div>
    </div>
  );
}
